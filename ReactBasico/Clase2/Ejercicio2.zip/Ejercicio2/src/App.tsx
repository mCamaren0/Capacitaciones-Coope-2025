import './App.css'
import TipoCambioCapturar from './TipoCambioCapturar'

function App() {

  return (
    <>
      <div className="card">
        <h1>Ejercicio #2</h1>
        <h1>Calculadora de divisas</h1> 
      </div>
      <TipoCambioCapturar></TipoCambioCapturar>
    </>
  )
}

export default App
