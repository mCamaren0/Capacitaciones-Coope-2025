# Notas del ejercicio

El archivo equipos.json, corresponde al archivo index.html
El archivo equipos2.json, corresponde al archivo index2.html

Los archivos
1. equipos.json
2. equipos2.json

Son json's generados a partir de la imagen del link proporcionado, **cada json tiene una estructura diferente**. No encontre un api que expusiera la informacion y recorde qué,
dentro de los programas a instalar en la primera clase, se encontraba json-server, por esta razon decidi hacerlo asi.
Para exponerlos seria lo siguiente:

Ejercicio index.html:
1. Abrir un terminal
2. Ejecutar el comando json-server --watch equipos.json
3. Ejecutar la pagina con liveServer


Ejercicio index2.html
1. Abrir un terminal
2. Ejecutar el comando json-server --watch equipos2.json
3. Ejecutar la pagina con liveServer